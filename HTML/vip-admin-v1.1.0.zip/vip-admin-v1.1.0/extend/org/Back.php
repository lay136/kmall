<?php
namespace org;
use think\Db;

class Back {

    /**
     * 备份类
     * 2017/03/08
     *
     * 使用方法:
        // 备份类
        $bak = new Back();
        // 获取表名
        $tables = $bak->getTables();
        // 日期
        $day = date("Y-m-d",time());
        // 随机数据
        $time = substr(time(),6,4);
        // 文件路径
        $filePath = 'static/admin/sql/back_'.$day.'_'.$time.'.sql';
        // 将表结构写入到文件
        $structure = $bak->structureToFile($tables,$filePath);
        // 将表数据写入到文件
        $flag = $bak->tableDataToFile($tables,$filePath);
        if($structure && $flag){
            $data['status'] = 1;
            $data['msg'] = '备份成功';
        }else{
            $data['msg'] = '备份出错';
        }
     *
     *
     */

    // 保存字符串到文件
    public function strToFile($fName,$sData){
        file_put_contents($fName,$sData,FILE_APPEND);
    }

    // 释放资源
    public function unRelease($res){
        unset($res);
    }

    // 获取表名数据
    public function getTables(){
        $tables = Db::query('SHOW TABLES');
        foreach($tables as $v){
            foreach($v as $vv){
                $data[] = $vv;
            }
        }
        return $data;
    }

    // 获取表结构数据
    public function getTableStructure($tableName){
        return Db::query('show create table '.$tableName)[0];
    }

    // 将每个表的表结构导出到文件
    public function structureToFile($tables,$fName){
        if( !is_array($tables) ){
            return false;
        }
        // 循环写入表结构
        foreach($tables as $v){
            $file = "-- ----------------------------\r\n";
            $file .= "-- Table structure for `".$v."`\r\n";
            $file .= "-- ----------------------------\r\n";
            $file .= "DROP TABLE IF EXISTS `".$v."`;\r\n";
            $structure = $this->getTableStructure($v);
            $sqlStr = $file.$structure['Create Table'].";\r\n\r\n";
            //追加到文件
            $this->strToFile($fName,$sqlStr);
        }
        return true;
    }

    // 将每个表的表数据写入到文件
    public function tableDataToFile($tables,$fName){
        if( !is_array($tables) ){
            return false;
        }
        // 循环写入表结构
        foreach($tables as $v){
            $res = Db::query('select * from '.$v);
            //如果表中没有数据，则继续下一张表
            if(count($res) < 1) continue;
            $file = "-- ----------------------------\r\n";
            $file .= "-- Records for `".$v."`\r\n";
            $file .= "-- ----------------------------\r\n";
            //追加到文件
            $this->strToFile($fName,$file);
            // 循环遍历数据
            foreach($res as $vv){
                $sqlStr = "INSERT INTO `".$v."` VALUES (";
                foreach($vv as $val){
                    $sqlStr .= "'".$val."', ";
                }
                //去掉最后一个逗号和空格
                $sqlStr = substr($sqlStr,0,strlen($sqlStr)-2);
                $sqlStr .= ");\r\n";
                // 写入文件
                $this->strToFile($fName,$sqlStr);
            }
            // 添加最后的换行
            $this->strToFile($fName,"\r\n");
            // 释放资源
            $this->unRelease($res);
        }
        return true;
    }


}